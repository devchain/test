import { TestBed } from '@angular/core/testing';

import { PlatformRestAPIService } from './platform-rest-api.service';

describe('PlatformRestAPIService', () => {
  let service: PlatformRestAPIService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PlatformRestAPIService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
