import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse} from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpWrapperService {

  constructor(private _http: HttpClient) { }

  get(url:string,options:any){
    return this._http.get(url,options).pipe(catchError(this.handleError));
  }

  //Error Handle
  private handleError(error: HttpErrorResponse){
    let errorMessage = '';

    if(error.error instanceof ErrorEvent){
      //error client
      errorMessage = error.error.message; 
    } else {
      //error server
      errorMessage = `Error Code: ${error.status}, ` + `message: ${error.message}`;
    }

    return throwError(errorMessage);
  }
}
