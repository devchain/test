import { Injectable,ErrorHandler } from '@angular/core';

@Injectable()
export class GlobalErrorHandlerService implements ErrorHandler {

  constructor() { }

  handleError(error: any) {
    console.log('Error From Global Error Handler: ',error);
    //todo
    //add Logger Service here to log all global error thrown to local/server
  }
}
