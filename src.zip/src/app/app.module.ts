import { NgModule,ErrorHandler  } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CommonHeadersInterceptor } from './services/core/interceptors/common-headers.interceptor';
import { GlobalHttpErrorHandlerInterceptor } from './services/core/interceptors/global-http-error-handler.interceptor';
import { GlobalErrorHandlerService } from './services/core/errorHandler/global-error-handler.service';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [
    {provide: ErrorHandler, useClass:GlobalErrorHandlerService},
    {provide:HTTP_INTERCEPTORS, useClass:CommonHeadersInterceptor,multi:true},
    {provide:HTTP_INTERCEPTORS, useClass:GlobalHttpErrorHandlerInterceptor,multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
